

$(window).scroll(function(){
	var st = $(this).scrollTop();
	
	$(".header_text").css({
		"transform" : "translate(0%, " + st + "%"
	});
	
	/*$(".sect_2").css({
		"transform" : "translate(0%, -" + st/10 + "%"
	});*/
});
	
	jQuery(function($) {
		$(window).scroll(function(){
			if($(this).scrollTop()>140){
				$('#navigation').addClass('fixed');
			}
			else if ($(this).scrollTop()<140){
				$('#navigation').removeClass('fixed');
			}
		});
	});